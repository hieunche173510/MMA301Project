import React from "react";
import {
  Card,
  CardContent,
  Typography,
  Button,
  Box,
  Chip,
  Avatar,
  Grid,
  Divider,
  IconButton,
  Tooltip,
} from "@mui/material";
import { Link } from "react-router-dom";
import FavoriteIcon from "@mui/icons-material/Favorite";
import InfoIcon from "@mui/icons-material/Info";
import PaletteIcon from "@mui/icons-material/Palette";
import GrassIcon from "@mui/icons-material/Grass";
import PublicIcon from "@mui/icons-material/Public";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";

const OrchidCard = ({ orchid }) => {
  return (
    <Card
      sx={{
        height: "80%",
        borderRadius: 4,
        position: "relative",
        overflow: "visible",
        bgcolor: "background.paper",
        boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
        "&:before": {
          content: '""',
          position: "absolute",
          height: "40%",
          width: "100%",
          top: 0,
          left: 0,
          backgroundColor: "#f0f7ff",
          borderTopLeftRadius: 16,
          borderTopRightRadius: 16,
          zIndex: 0,
        },
      }}
    >
      <CardContent
        sx={{
          p: 0,
          height: "100%",
          position: "relative",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
        }}
      >
        {/* Image Circle */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            position: "relative",
            zIndex: 1,
            pt: 3,
          }}
        >
          <Avatar
            src={orchid.image}
            alt={orchid.name}
            sx={{
              width: 120,
              height: 120,
              border: "4px solid white",
              boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
            }}
          />
          {orchid.isSpecial && (
            <Box
              sx={{
                position: "absolute",
                top: 12,
                right: 24,
                backgroundColor: "secondary.main",
                color: "white",
                borderRadius: "50%",
                width: 36,
                height: 36,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <FavoriteIcon fontSize="small" />
            </Box>
          )}
        </Box>

        {/* Content Area */}
        <Box sx={{ px: 3, pt: 2, pb: 2, textAlign: "center" }}>
          <Typography
            variant="h6"
            component="h2"
            sx={{
              fontWeight: 600,
              fontSize: "1.1rem",
              mb: 1,
            }}
          >
            {orchid.name}
          </Typography>

          {/* Rating Pill */}
          <Box
            sx={{
              display: "inline-flex",
              alignItems: "center",
              bgcolor: "rgba(255, 193, 7, 0.15)",
              px: 1.5,
              py: 0.5,
              borderRadius: 10,
              mb: 2,
            }}
          >
            <Typography
              variant="body2"
              sx={{ fontWeight: 600, color: "orange.dark" }}
            >
              {orchid.rating}
            </Typography>
            <Typography
              variant="body2"
              sx={{ ml: 0.5, color: "text.secondary" }}
            >
              / 5.0
            </Typography>
          </Box>

          <Divider sx={{ my: 2 }} />

          {/* Info Grid */}
          <Grid container spacing={1} sx={{ mb: 2 }}>
            <Grid item xs={6}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <PublicIcon
                  sx={{ color: "primary.light", mr: 1, fontSize: 18 }}
                />
                <Typography variant="body2" color="text.secondary" noWrap>
                  {orchid.origin}
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <GrassIcon
                  sx={{ color: "success.light", mr: 1, fontSize: 18 }}
                />
                <Typography variant="body2" color="text.secondary" noWrap>
                  {orchid.category}
                </Typography>
              </Box>
            </Grid>
          </Grid>

          {/* Color Chip */}
          <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
            <Chip
              icon={<PaletteIcon />}
              label={orchid.color}
              size="small"
              sx={{
                px: 1,
                backgroundColor: "rgba(0,0,0,0.04)",
                "& .MuiChip-icon": {
                  color: "primary.main",
                },
              }}
            />
          </Box>
        </Box>

        {/* Action Footer */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            bgcolor: "primary.main",
            color: "white",
            p: 1.5,
            borderBottomLeftRadius: 16,
            borderBottomRightRadius: 16,
            mt: "auto",
          }}
        >
          <Tooltip title="View Details">
            <IconButton
              size="small"
              sx={{ color: "white", backgroundColor: "rgba(255,255,255,0.15)" }}
            >
              <InfoIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          <Button
            component={Link}
            to={`/orchid/${orchid.id}`}
            variant="contained"
            size="small"
            endIcon={<ArrowForwardIcon />}
            sx={{
              bgcolor: "white",
              color: "primary.main",
              "&:hover": {
                bgcolor: "rgba(255,255,255,0.9)",
              },
            }}
          >
            Xem chi tiết
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default OrchidCard;
