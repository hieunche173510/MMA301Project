import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Container,
  Typography,
  Button,
  Box,
  Chip,
  Divider,
  Grid,
  IconButton,
  Card,
  Tabs,
  Tab,
  Avatar,
  useTheme,
  useMediaQuery,
  Breadcrumbs,
} from "@mui/material";
import { orchids } from "../data/ListOfOrchids";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import FavoriteIcon from "@mui/icons-material/Favorite";
import ShareIcon from "@mui/icons-material/Share";
import BookmarkIcon from "@mui/icons-material/Bookmark";
import WaterDropIcon from "@mui/icons-material/WaterDrop";
import WbSunnyIcon from "@mui/icons-material/WbSunny";
import ThermostatIcon from "@mui/icons-material/Thermostat";
import PublicIcon from "@mui/icons-material/Public";
import CollectionsIcon from "@mui/icons-material/Collections";
import InfoIcon from "@mui/icons-material/Info";
import LocalFloristIcon from "@mui/icons-material/LocalFlorist";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import StarIcon from "@mui/icons-material/Star";
import ZoomInIcon from "@mui/icons-material/ZoomIn";
import { Link } from "react-router-dom";

function OrchidDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));
  const orchid = orchids.find((o) => o.id === parseInt(id));
  const [tabValue, setTabValue] = useState(0);
  const [favorited, setFavorited] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  if (!orchid) {
    return (
      <Container maxWidth="lg" sx={{ py: 8, textAlign: "center" }}>
        <Box
          sx={{
            p: 6,
            borderRadius: 4,
            bgcolor: "background.paper",
            boxShadow: "0 8px 40px rgba(0,0,0,0.08)",
          }}
        >
          <Typography variant="h4" color="text.secondary" gutterBottom>
            Không tìm thấy loài lan
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            paragraph
            sx={{ mb: 4 }}
          >
            Chúng tôi không thể tìm thấy loài lan bạn đang tìm kiếm
          </Typography>
          <Button
            variant="contained"
            onClick={() => navigate("/")}
            startIcon={<ArrowBackIcon />}
            size="large"
            sx={{
              borderRadius: 2,
              px: 4,
              py: 1.5,
              textTransform: "none",
              fontSize: "1rem",
              boxShadow: 2,
            }}
          >
            Quay lại bộ sưu tập
          </Button>
        </Box>
      </Container>
    );
  }

  const careInstructions = {
    water: "Once per week, allowing soil to dry between waterings",
    light: "Bright, indirect light. Avoid direct sunlight",
    temperature: "65-80°F (18-27°C), minimal temperature fluctuation",
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Breadcrumbs */}
      <Button
        variant="outlined"
        onClick={() => navigate("/")}
        startIcon={<ArrowBackIcon />}
        sx={{
          borderRadius: 2,
          py: 1.5,
          mb: 2,
          textTransform: "none",
        }}
      >
        Quay lại bộ sưu tập
      </Button>

      {/* Main Content */}
      <Box
        sx={{
          borderRadius: 4,
          overflow: "hidden",
          bgcolor: "background.paper",
          boxShadow: "0 10px 40px rgba(0,0,0,0.1)",
          mb: 4,
        }}
      >
        <Grid container>
          {/* Image Section with Overlay */}
          <Grid item xs={12} md={5} sx={{ position: "relative" }}>
            <Box
              sx={{
                height: isMobile ? 300 : 600,
                position: "relative",
                overflow: "hidden",
                bgcolor: "#000",
              }}
            >
              <Box
                component="img"
                src={orchid.image}
                alt={orchid.name}
                sx={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  opacity: 0.85,
                  transition: "transform 0.3s ease-in-out",
                  "&:hover": {
                    transform: "scale(1.05)",
                  },
                }}
              />

              {/* Actions Overlay */}
              <Box
                sx={{
                  position: "absolute",
                  top: 16,
                  right: 16,
                  display: "flex",
                  gap: 1,
                }}
              >
                <IconButton
                  sx={{
                    bgcolor: "rgba(255,255,255,0.9)",
                    "&:hover": { bgcolor: "white" },
                  }}
                  onClick={() => setFavorited(!favorited)}
                >
                  <FavoriteIcon color={favorited ? "error" : "action"} />
                </IconButton>
                <IconButton
                  sx={{
                    bgcolor: "rgba(255,255,255,0.9)",
                    "&:hover": { bgcolor: "white" },
                  }}
                >
                  <ShareIcon color="action" />
                </IconButton>
                <IconButton
                  sx={{
                    bgcolor: "rgba(255,255,255,0.9)",
                    "&:hover": { bgcolor: "white" },
                  }}
                  onClick={() => setSaved(!saved)}
                >
                  <BookmarkIcon color={saved ? "primary" : "action"} />
                </IconButton>
              </Box>

              {/* Origin Badge */}
              <Box
                sx={{
                  position: "absolute",
                  bottom: 20,
                  left: 20,
                  display: "flex",
                  alignItems: "center",
                  bgcolor: "rgba(0,0,0,0.7)",
                  color: "white",
                  px: 2,
                  py: 1,
                  borderRadius: 20,
                }}
              >
                <PublicIcon sx={{ mr: 1, fontSize: 20 }} />
                <Typography variant="body2">{orchid.origin}</Typography>
              </Box>

              {/* Special Badge */}
              {orchid.isSpecial && (
                <Box
                  sx={{
                    position: "absolute",
                    top: 20,
                    left: 20,
                    display: "flex",
                    alignItems: "center",
                    bgcolor: theme.palette.secondary.main,
                    color: "white",
                    px: 2,
                    py: 1,
                    borderRadius: 20,
                  }}
                >
                  <StarIcon sx={{ mr: 1, fontSize: 20 }} />
                  <Typography variant="body2">Loài quý hiếm</Typography>
                </Box>
              )}
            </Box>
          </Grid>

          {/* Content Section */}
          <Grid item xs={12} md={7}>
            <Box
              sx={{
                p: 4,
                height: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              {/* Header */}
              <Box sx={{ mb: 3 }}>
                <Typography
                  variant="h3"
                  component="h1"
                  gutterBottom
                  sx={{
                    fontWeight: 600,
                    fontSize: { xs: "1.75rem", md: "2.5rem" },
                  }}
                >
                  {orchid.name}
                </Typography>

                {/* Rating Bar */}
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    bgcolor: "rgba(255, 193, 7, 0.1)",
                    width: "fit-content",
                    px: 2,
                    py: 0.5,
                    borderRadius: 2,
                    mb: 2,
                  }}
                >
                  {[...Array(5)].map((_, i) => (
                    <Box
                      key={i}
                      component="span"
                      sx={{
                        width: 20,
                        height: 8,
                        borderRadius: 4,
                        mr: 0.5,
                        bgcolor:
                          i < Math.floor(orchid.rating)
                            ? "warning.main"
                            : "grey.300",
                      }}
                    />
                  ))}
                  <Typography variant="body2" sx={{ ml: 1, fontWeight: 600 }}>
                    {orchid.rating}/5
                  </Typography>
                </Box>

                {/* Tags */}
                <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mt: 2 }}>
                  <Chip
                    label={orchid.category}
                    color="primary"
                    sx={{
                      borderRadius: "8px",
                      fontWeight: 500,
                      px: 1,
                    }}
                  />
                  <Chip
                    label={orchid.color}
                    sx={{
                      borderRadius: "8px",
                      bgcolor: "rgba(0,0,0,0.05)",
                      fontWeight: 500,
                      px: 1,
                    }}
                  />
                </Box>
              </Box>

              <Divider />

              {/* Content Tabs */}
              <Tabs
                value={tabValue}
                onChange={handleTabChange}
                sx={{
                  mb: 3,
                  mt: 2,
                  "& .MuiTab-root": {
                    textTransform: "none",
                    minWidth: 100,
                    fontSize: "1rem",
                    fontWeight: 500,
                  },
                }}
              >
                <Tab
                  icon={<InfoIcon />}
                  label="Thông tin"
                  iconPosition="start"
                />
                <Tab
                  icon={<LocalFloristIcon />}
                  label="Chăm sóc"
                  iconPosition="start"
                />
                <Tab
                  icon={<CollectionsIcon />}
                  label="Hình ảnh"
                  iconPosition="start"
                />
              </Tabs>

              {/* Tab Content */}
              <Box sx={{ flexGrow: 1, overflowY: "auto" }}>
                {tabValue === 0 && (
                  <Box>
                    <Typography
                      variant="body1"
                      paragraph
                      sx={{
                        fontSize: "1.1rem",
                        lineHeight: 1.7,
                        color: "text.primary",
                      }}
                    >
                      <span style={{ fontWeight: 600 }}>{orchid.name}</span> là
                      một loài lan thuộc nhóm {orchid.category.toLowerCase()} có
                      nguồn gốc từ {orchid.origin}. Loài lan này nổi bật với màu
                      hoa {orchid.color.toLowerCase()} đặc trưng và vẻ đẹp tinh
                      tế.
                    </Typography>
                    <Typography
                      variant="body1"
                      paragraph
                      sx={{
                        fontSize: "1.1rem",
                        lineHeight: 1.7,
                        color: "text.primary",
                      }}
                    >
                      {orchid.isSpecial
                        ? `Đây là một trong những loài quý hiếm trong bộ sưu tập của chúng tôi. Lan ${orchid.name} được nhiều nhà sưu tập săn đón vì độ hiếm và vẻ đẹp độc đáo của nó.`
                        : `Lan ${orchid.name} là loài phổ biến được nhiều người yêu thích nhờ khả năng thích nghi tốt và vẻ đẹp bền lâu của hoa.`}
                    </Typography>
                  </Box>
                )}

                {tabValue === 1 && (
                  <Box>
                    <Typography
                      variant="h6"
                      gutterBottom
                      sx={{ fontWeight: 600, mb: 3 }}
                    >
                      Hướng dẫn chăm sóc
                    </Typography>

                    <Grid container spacing={3}>
                      <Grid item xs={12}>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            p: 2,
                            borderRadius: 2,
                            bgcolor: "background.neutral",
                          }}
                        >
                          <Avatar
                            sx={{
                              bgcolor: "primary.light",
                              mr: 2,
                              width: 48,
                              height: 48,
                            }}
                          >
                            <WaterDropIcon />
                          </Avatar>
                          <Box>
                            <Typography
                              variant="subtitle1"
                              sx={{ fontWeight: 600 }}
                            >
                              Nước
                            </Typography>
                            <Typography variant="body2">
                              {careInstructions.water}
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            p: 2,
                            borderRadius: 2,
                            bgcolor: "background.neutral",
                          }}
                        >
                          <Avatar
                            sx={{
                              bgcolor: "warning.light",
                              mr: 2,
                              width: 48,
                              height: 48,
                            }}
                          >
                            <WbSunnyIcon />
                          </Avatar>
                          <Box>
                            <Typography
                              variant="subtitle1"
                              sx={{ fontWeight: 600 }}
                            >
                              Ánh sáng
                            </Typography>
                            <Typography variant="body2">
                              {careInstructions.light}
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>

                      <Grid item xs={12}>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            p: 2,
                            borderRadius: 2,
                            bgcolor: "background.neutral",
                          }}
                        >
                          <Avatar
                            sx={{
                              bgcolor: "error.light",
                              mr: 2,
                              width: 48,
                              height: 48,
                            }}
                          >
                            <ThermostatIcon />
                          </Avatar>
                          <Box>
                            <Typography
                              variant="subtitle1"
                              sx={{ fontWeight: 600 }}
                            >
                              Nhiệt độ
                            </Typography>
                            <Typography variant="body2">
                              {careInstructions.temperature}
                            </Typography>
                          </Box>
                        </Box>
                      </Grid>
                    </Grid>

                    <Box
                      sx={{
                        mt: 4,
                        p: 3,
                        bgcolor: "rgba(76, 175, 80, 0.08)",
                        borderRadius: 2,
                      }}
                    >
                      <Typography
                        variant="subtitle1"
                        gutterBottom
                        sx={{ fontWeight: 600, color: "success.dark" }}
                      >
                        Lời khuyên của chuyên gia
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Loài lan {orchid.name} thích hợp nhất trong môi trường
                        có độ ẩm cao. Phun sương xung quanh (không phun trực
                        tiếp lên hoa) vào những ngày nóng sẽ giúp lan phát triển
                        tốt hơn.
                      </Typography>
                    </Box>
                  </Box>
                )}

                {tabValue === 2 && (
                  <Box>
                    <Typography
                      variant="subtitle1"
                      gutterBottom
                      sx={{ fontWeight: 600, mb: 3 }}
                    >
                      Bộ sưu tập hình ảnh
                    </Typography>

                    <Grid container spacing={2}>
                      {[...Array(4)].map((_, index) => (
                        <Grid item xs={6} sm={6} md={6} key={index}>
                          <Box
                            sx={{
                              borderRadius: 2,
                              overflow: "hidden",
                              height: 180,
                              position: "relative",
                              "&:hover": {
                                "& .overlay": {
                                  opacity: 1,
                                },
                              },
                            }}
                          >
                            <Box
                              component="img"
                              src={orchid.image}
                              alt={`${orchid.name} view ${index + 1}`}
                              sx={{
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                              }}
                            />
                            <Box
                              className="overlay"
                              sx={{
                                position: "absolute",
                                top: 0,
                                left: 0,
                                width: "100%",
                                height: "100%",
                                bgcolor: "rgba(0,0,0,0.4)",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                opacity: 0,
                                transition: "opacity 0.3s ease",
                                cursor: "pointer",
                              }}
                            >
                              <IconButton sx={{ color: "white" }}>
                                <ZoomInIcon />
                              </IconButton>
                            </Box>
                          </Box>
                        </Grid>
                      ))}
                    </Grid>
                  </Box>
                )}
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
}

// Missing import - add this

export default OrchidDetail;
