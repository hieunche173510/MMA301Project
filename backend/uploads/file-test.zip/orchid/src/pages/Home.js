// components/Home.js
import * as React from "react";
import { experimentalStyled as styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid2";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import { orchids } from "../data/ListOfOrchids";
import OrchidCard from "../components/OrchidCard";

// Styled component for wrapper of OrchidCard
const Item = styled(Box)(({ theme }) => ({
  backgroundColor: "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(2),
  height: "100%",
  transition: "transform 0.2s ease-in-out",
  "&:hover": {
    transform: "translateY(-4px)",
  },
}));

function Home() {
  return (
    <Container sx={{ py: 4 }}>
      <Typography
        variant="h4"
        component="h1"
        gutterBottom
        textAlign="center"
        color="primary"
        sx={{ mb: 4 }}
      >
        Our Orchid Collection
      </Typography>

      <Box sx={{ flexGrow: 1 }}>
        <Grid
          container
          spacing={{ xs: 2, md: 3 }}
          columns={{ xs: 4, sm: 8, md: 12 }}
        >
          {orchids.map((orchid, index) => (
            <Grid size={{ xs: 2, sm: 4, md: 4 }} key={index}>
              <Item>
                <OrchidCard orchid={orchid} />
              </Item>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Container>
  );
}

export default Home;
