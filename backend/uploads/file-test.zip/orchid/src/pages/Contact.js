// components/Contact.js
import React, { useState } from "react";
import {
  Container,
  Box,
  Typography,
  TextField,
  Button,
  Grid,
  Card,
  CardContent,
  Snackbar,
  Alert,
  styled,
  Divider,
  Paper,
  Avatar,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import {
  Phone as PhoneIcon,
  Email as EmailIcon,
  LocationOn as LocationIcon,
  AccessTime as TimeIcon,
  Send as SendIcon,
} from "@mui/icons-material";

// Styled components
const ContactWrapper = styled(Box)(({ theme }) => ({
  padding: theme.spacing(6, 0),
  background: "linear-gradient(to bottom, #f9fafb 0%, #ffffff 100%)",
}));

const StyledCard = styled(Card)(({ theme }) => ({
  height: "100%",
  transition: "transform 0.3s, box-shadow 0.3s",
  "&:hover": {
    transform: "translateY(-5px)",
    boxShadow: theme.shadows[8],
  },
  borderRadius: 12,
}));

const IconAvatar = styled(Avatar)(({ theme }) => ({
  width: 56,
  height: 56,
  backgroundColor: theme.palette.primary.light,
  color: theme.palette.primary.contrastText,
  marginBottom: theme.spacing(2),
}));

const ContactForm = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: 16,
  boxShadow: "0 6px 20px rgba(0, 0, 0, 0.08)",
  background: "#ffffff",
}));

function Contact() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setError("Please fill in all required fields");
      return;
    }
    // Here you would typically send the form data to a server
    setSubmitted(true);
    setError("");
    setOpenSnackbar(true);
    // Reset form
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    });
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  const contactInfo = [
    {
      icon: <LocationIcon />,
      title: "Our Location",
      details: [
        "123 Orchid Garden Street",
        "Flower District",
        "Garden City, GC 12345",
      ],
    },
    {
      icon: <PhoneIcon />,
      title: "Phone Numbers",
      details: ["+1 (555) 123-4567", "+1 (555) 765-4321"],
    },
    {
      icon: <EmailIcon />,
      title: "Email Address",
      details: ["info@orchidshop.com", "support@orchidshop.com"],
    },
    {
      icon: <TimeIcon />,
      title: "Business Hours",
      details: [
        "Monday - Friday: 9:00 AM - 6:00 PM",
        "Saturday: 10:00 AM - 4:00 PM",
        "Sunday: Closed",
      ],
    },
  ];

  return (
    <ContactWrapper>
      <Container maxWidth="lg">
        {/* Section Header */}
        <Box mb={6} textAlign="center">
          <Typography
            variant="h3"
            component="h1"
            fontWeight="bold"
            gutterBottom
            color="primary"
            sx={{
              position: "relative",
              display: "inline-block",
              "&:after": {
                content: '""',
                position: "absolute",
                width: "60px",
                height: "3px",
                background: theme.palette.primary.main,
                bottom: "-10px",
                left: "calc(50% - 30px)",
              },
            }}
          >
            Get in Touch
          </Typography>
          <Typography
            variant="subtitle1"
            color="text.secondary"
            sx={{ maxWidth: 600, mx: "auto", mt: 3 }}
          >
            Have questions about our orchids or need assistance with your order?
            We're here to help and would love to hear from you!
          </Typography>
        </Box>

        <Grid container spacing={5}>
          {/* Contact Form Section */}
          <Grid item xs={12} md={7}>
            <ContactForm elevation={0}>
              <Typography variant="h5" fontWeight="600" mb={3}>
                Send us a Message
              </Typography>

              {error && (
                <Alert severity="error" sx={{ mb: 3 }}>
                  {error}
                </Alert>
              )}

              <form onSubmit={handleSubmit}>
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      required
                      fullWidth
                      label="Your Name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      variant="outlined"
                      InputProps={{ sx: { borderRadius: 2 } }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      required
                      fullWidth
                      label="Email Address"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      variant="outlined"
                      InputProps={{ sx: { borderRadius: 2 } }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      variant="outlined"
                      InputProps={{ sx: { borderRadius: 2 } }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      label="Your Message"
                      name="message"
                      multiline
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      variant="outlined"
                      InputProps={{ sx: { borderRadius: 2 } }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Button
                      type="submit"
                      variant="contained"
                      size="large"
                      startIcon={<SendIcon />}
                      sx={{
                        borderRadius: 3,
                        py: 1.2,
                        px: 4,
                        textTransform: "none",
                        fontWeight: 600,
                        boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
                      }}
                    >
                      Send Message
                    </Button>
                  </Grid>
                </Grid>
              </form>

              {/* Additional Information */}
              <Box sx={{ mt: 4 }}>
                <Divider sx={{ mb: 2 }} />
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}
                >
                  <TimeIcon fontSize="small" color="primary" /> We typically
                  respond within 24 business hours.
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ display: "flex", alignItems: "center", gap: 1 }}
                >
                  <PhoneIcon fontSize="small" color="primary" /> For urgent
                  inquiries, please call our customer service number.
                </Typography>
              </Box>
            </ContactForm>
          </Grid>

          {/* Contact Information Section */}
          <Grid item xs={12} md={5}>
            <Box>
              <Typography variant="h5" fontWeight="600" mb={3}>
                Contact Information
              </Typography>
              <Grid container spacing={3}>
                {contactInfo.map((info, index) => (
                  <Grid key={index} item xs={12} sm={isMobile ? 12 : 6}>
                    <StyledCard>
                      <CardContent sx={{ textAlign: "center", p: 3 }}>
                        <IconAvatar>{info.icon}</IconAvatar>
                        <Typography
                          variant="h6"
                          fontWeight="medium"
                          gutterBottom
                        >
                          {info.title}
                        </Typography>
                        <Box sx={{ mt: 1 }}>
                          {info.details.map((detail, idx) => (
                            <Typography
                              key={idx}
                              variant="body2"
                              color="text.secondary"
                              sx={{ mb: 0.5 }}
                            >
                              {detail}
                            </Typography>
                          ))}
                        </Box>
                      </CardContent>
                    </StyledCard>
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Grid>
        </Grid>
      </Container>

      {/* Success Message Snackbar */}
      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity="success"
          variant="filled"
        >
          Thank you for your message! We'll get back to you soon.
        </Alert>
      </Snackbar>
    </ContactWrapper>
  );
}

export default Contact;
